document.querySelector('form').addEventListener('submit', function(event){
    event.preventDefault();
    // получаем num1
    let num1 = +event.target.elements.num1.value;
     // получаем num2
    let num2 = +event.target.elements.num2.value;
    // выводим
    document.querySelector('.out').textContent = num1 + num2;
});