import React, {useRef} from 'react';

function App() {

  const out = useRef();
  console.log(out);

  const buttonClick = () => {
    console.log(out);
    out.current.textContent += "GO"
  }

  return (
    <>
      <div><button onClick={buttonClick}>Button</button></div>
      <div className="out" ref={out}></div>
    </>
  );
}

export default App;
