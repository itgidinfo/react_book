function Test (props) {

    console.log(props);

    return (
        <>
        <p>Вывод props:</p>
        <p>{props.f}</p>
        <p>{props.g}</p>
        </>
    )
}

export default Test;