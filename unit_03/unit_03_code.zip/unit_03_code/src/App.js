import './App.css';

function App() {
  // создание и вывод константы
  const d1 = 567;
  const d2 = 'Hello';
  // создание и вывод переменной
  let d3 = 7;
  // вывод массива
  const d4 = [11,22,33];
  // Присволить inline стиль
  const redColor = 'red';
  // Присвоить объект как стиль
  const objectStyles = {
    'fontWeight' : 'bold',
    'color' : 'orange',
    'textTransform' : 'uppercase'
  }
  // Вывод класса CSS
  const bold = 'text-bold';
  // Создаем элемент
  const head1 = <h1>Its h1</h1>;
  // Создание блокового элемента
  const list = (
      <ul>
        <li>Apples</li>
        <li>Bananas</li>
        <li>Cherries</li>
      </ul>
  );
  // Условный рендеринг
  const d5 = 5;
  // Условный рендеринг с классом

  // Вызов функции
  function test1(){
    let c = 9;
    return c*7;
  }

  const test2 = () => {
    let c = 10;
    return 5 * c;
  }

  const t = (
      <table>
        <tbody>
        <tr>
          <th>Head1</th>
          <th>Head2</th>
        </tr>
          <tr>
            <td>One</td>
            <td>Two</td>
          </tr>
        </tbody>
      </table>
  );


  return (
    <div className="App">
      <p>Вывод константы {d1}</p>
      <p>Конкатенация текста {d2 + 'World'}</p>
      <p>Вывод переменной {d3*6}</p>
      <div>Вывод массива:
        {d4.map(item => item + ' ' )}
      </div>
      <div>Вывод массива списком:
        {d4.map(item => <li key={item}>{item}</li>)}
      </div>
      <div>Сумма элементов массива:
        {d4.reduce((accum,item) => accum + item)}
      </div>
      <p style={{color: redColor}}>Применяем inline стиль</p>
      <p style={objectStyles}>Применяем объект как инлайн стили</p>
      <p className = {`some-class ${bold}`}>Вывод класса CSS из переменной</p>
      <div>Create Element {head1}</div>
      <div>Создание блокового элемента
        {list}
      </div>
      <div>Условный рендеринг:
        <p>{d5 < 10 ? "Hello" : "Goodbye"}</p>
      </div>
      <div className={d5 < 10 ? "hide" : "show"}>Hide - show element</div>

      <div>Вызов функции: {test1()}</div>

      <div>Вызов функции стрелочной: {test2()}</div>

      <div>Таблица:
        {t}
      </div>
    </div>
  );
}

export default App;
