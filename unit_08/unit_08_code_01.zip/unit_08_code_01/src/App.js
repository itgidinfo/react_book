import {useSelector} from 'react-redux';
import {selectSampleData2} from './reducers/reducerSlice1';

function App() {
  const data2 = useSelector(selectSampleData2); // получаем данные из store

  return (
    <div className="App">
      <h1>React redux - simple example</h1>
      {data2}
    </div>
  );
}

export default App;
