import { configureStore } from '@reduxjs/toolkit';
import reducerSlice1 from '../reducers/reducerSlice1';

// тут мы собираем наши кусочки (slice) store

export default configureStore({
	reducer: {
		reducer1 : reducerSlice1
	},
});











