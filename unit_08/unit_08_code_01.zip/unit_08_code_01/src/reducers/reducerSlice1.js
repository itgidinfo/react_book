import { createSlice } from '@reduxjs/toolkit';

export const reducerSlice1 = createSlice({
	name: 'reducerSliceNumberOne',
	initialState: {
		sampleData_1 : {
			'1650981065' : 'Купить молока',
			'1650991065' : 'Купить огурцов',
		},
		sampleData_2 : 500
	},
	reducers: {},
});

// для получения данных
export const selectSampleData2 = state => state.reducer1.sampleData_2;

export default reducerSlice1.reducer;

