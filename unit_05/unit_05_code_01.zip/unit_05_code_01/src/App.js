import {useState} from "react";

function App() {

  // создаем стейт и задаем начальное значение
  const [count, setCount] = useState(1);

  const buttonCount = () => {
    // изменяем значение
    let temp = count;
    temp++;
    //  сохраняем изменения
    setCount(temp);
  }

  return (
    <div className="App">
      <button onClick = {buttonCount}>Go</button>
      <p>{count}</p>
    </div>
  );
}

export default App;
