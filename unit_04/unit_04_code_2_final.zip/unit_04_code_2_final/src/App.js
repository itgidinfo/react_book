import Aside from  './Aside';

function App() {
  return (
    <div className="App">
      <Aside />
    </div>
  );
}

export default App;
