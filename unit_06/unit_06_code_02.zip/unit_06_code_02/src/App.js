
import './App.css';

function App() {

  const formHandler = (event) => {
    event.preventDefault();
    let num1 = +document.querySelector('.num1').value;
    let num2 = +document.querySelector('.num2').value;
    document.querySelector('.out').innerHTML = num1 + num2;
  }

  return (
    <div className="App">
      <form onSubmit={formHandler}>
        <input type="number" className ="num1" />
        <input type="number" className ="num2" />
        <input type="submit" value = "Sum"  />
      </form>
      <div className ="out"></div>
    </div>
  );
}

export default App;
